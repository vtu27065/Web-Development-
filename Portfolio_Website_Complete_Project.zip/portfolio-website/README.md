# Personal Portfolio Website

A responsive portfolio website built with semantic HTML5, CSS3, and vanilla JavaScript. It demonstrates responsive layouts, CSS Grid/Flexbox, DOM manipulation, events, arrays, objects, filtering, search, form validation, and GitHub Pages deployment.

## Project structure

```text
portfolio-website/
├── index.html
├── style.css
├── script.js
├── README.md
├── project-report.md
└── assets/
    └── (add your images and other assets here)
```

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a browser.
3. For a smoother development workflow, use Visual Studio Code with the Live Server extension (optional).

No build tools or package installation are required.

## Personalize before submitting

Search in `index.html` and replace the sample identity:
- `Alex Morgan` / `AM`
- `alex.morgan@example.com`
- Role, biography, skills, project names and descriptions
- Project links and social links (add your real profiles if needed)

Update the skills to honestly reflect your current experience. Replace the sample project cards with your own work. Add screenshots to `assets/` if required by your assignment. The contact form currently validates input in the browser only; it does not send or store messages. Connect a backend or a form service if you need real submissions.

## Git setup and version control

Install Git from https://git-scm.com/downloads, then set your identity:

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

From inside the project folder:

```bash
git init
git status
git add index.html style.css script.js README.md project-report.md
git commit -m "Create responsive portfolio structure"
git add .
git commit -m "Add portfolio styling and responsive layouts"
git commit -m "Implement project filters and contact form validation"
git log --oneline
```

Create a **public** repository on GitHub named `portfolio-website`. If you created an empty repository without a README, connect and push:

```bash
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/portfolio-website.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. If a remote already exists, check it with `git remote -v` instead of adding it a second time.

## Deploy with GitHub Pages

1. Push all project files to the public GitHub repository.
2. Open the repository on GitHub and select **Settings**.
3. Select **Pages** in the sidebar.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for the deployment to finish. The live site should be available at:
   `https://YOUR-USERNAME.github.io/portfolio-website/`
7. Open the live link and test navigation, filters, search, form validation, mobile layout, and asset loading.

If your repository is named `YOUR-USERNAME.github.io`, the site URL is instead `https://YOUR-USERNAME.github.io/`.

## Final test checklist

- [ ] Replace all sample identity and contact details.
- [ ] Test on desktop, tablet, and mobile widths.
- [ ] Check every navigation link and project filter.
- [ ] Test search with matching and non-matching text.
- [ ] Test form with invalid and valid values.
- [ ] Check browser console for errors.
- [ ] Confirm repository is public.
- [ ] Confirm Git history contains meaningful commits.
- [ ] Confirm GitHub Pages is published and the live URL works.
- [ ] Add actual screenshots and update `project-report.md`.
