// Portfolio interactions: mobile navigation, project filters/search, form validation.
"use strict";

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const navLinkItems = document.querySelectorAll(".nav-link");
const filterButtons = document.querySelectorAll(".filter-button");
const projectCards = Array.from(document.querySelectorAll(".project-card"));
const projectSearch = document.getElementById("projectSearch");
const emptyState = document.getElementById("emptyState");
const contactForm = document.getElementById("contactForm");
const formFeedback = document.getElementById("formFeedback");

let activeFilter = "all";

const projects = projectCards.map((card) => ({
  title: card.dataset.title.toLowerCase(),
  category: card.dataset.category,
  element: card
}));

// Toggle the mobile navigation menu.
menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
});

navLinkItems.forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

// Highlight the navigation item for the current section.
const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      navLinkItems.forEach((link) => {
        link.classList.toggle("active", link.getAttribute("href") === `#${entry.target.id}`);
      });
    }
  });
}, { rootMargin: "-35% 0px -55% 0px" });

document.querySelectorAll("main section[id]").forEach((section) => sectionObserver.observe(section));

// Filter and search projects together.
function updateProjects() {
  const query = projectSearch.value.trim().toLowerCase();
  let visibleCount = 0;

  projects.forEach((project) => {
    const matchesFilter = activeFilter === "all" || project.category === activeFilter;
    const matchesSearch = project.title.includes(query) ||
      project.element.textContent.toLowerCase().includes(query);
    const visible = matchesFilter && matchesSearch;
    project.element.hidden = !visible;
    if (visible) visibleCount += 1;
  });

  emptyState.hidden = visibleCount !== 0;
}

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    filterButtons.forEach((item) => item.classList.toggle("active", item === button));
    updateProjects();
  });
});

projectSearch.addEventListener("input", updateProjects);

// Small validation helpers.
function setFieldError(fieldId, errorId, message) {
  const field = document.getElementById(fieldId);
  const error = document.getElementById(errorId);
  field.classList.toggle("invalid", Boolean(message));
  field.setAttribute("aria-invalid", String(Boolean(message)));
  if (error) error.textContent = message;
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

contactForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const subject = document.getElementById("subject").value.trim();
  const message = document.getElementById("message").value.trim();
  let valid = true;

  const nameError = name.length < 2 ? "Please enter at least 2 characters." : "";
  const emailError = isValidEmail(email) ? "" : "Please enter a valid email address.";
  const messageError = message.length < 10 ? "Please enter at least 10 characters." : "";

  setFieldError("name", "nameError", nameError);
  setFieldError("email", "emailError", emailError);
  setFieldError("message", "messageError", messageError);

  if (!subject) {
    document.getElementById("subject").classList.add("invalid");
    valid = false;
  } else {
    document.getElementById("subject").classList.remove("invalid");
  }

  if (nameError || emailError || messageError || !subject) valid = false;

  if (!valid) {
    formFeedback.textContent = "Please correct the highlighted fields and try again.";
    formFeedback.className = "form-note error";
    return;
  }

  formFeedback.textContent = `Thanks, ${name}! Your details passed validation. This demo does not send email; connect a backend or form service to receive messages.`;
  formFeedback.className = "form-note success";
  contactForm.reset();
  document.querySelectorAll(".field-error").forEach((item) => item.textContent = "");
  document.querySelectorAll(".invalid").forEach((item) => {
    item.classList.remove("invalid");
    item.setAttribute("aria-invalid", "false");
  });
});

document.getElementById("currentYear").textContent = new Date().getFullYear();
