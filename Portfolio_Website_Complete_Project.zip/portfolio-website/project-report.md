# Final Project Report: Personal Portfolio Website

## Project Title
Personal Portfolio Website

## Project Objective
The objective of this project is to apply the HTML, CSS, JavaScript, Git, and GitHub concepts learned during the six-week web development internship by creating a responsive and interactive personal portfolio website.

## Project Overview
The portfolio presents a developer introduction, biography, technical skills, selected projects, development approach, and contact section. It uses a dark visual theme, responsive cards, and a clear navigation structure. The page is designed to adapt to desktop, tablet, and mobile screen sizes.

## Technologies Used
- **HTML5:** semantic sections, navigation, project cards, and contact form.
- **CSS3:** custom properties, typography, Box Model, Flexbox, Grid, transitions, and media queries.
- **JavaScript:** mobile menu, active navigation state, project filtering, search, form validation, and dynamic footer year.
- **Git and GitHub:** version control, repository hosting, commit history, and GitHub Pages deployment.

## Main Features
1. Responsive navigation with a mobile menu.
2. Hero section and developer profile summary.
3. Skills section showing core web technologies.
4. Project cards with category filters and live search.
5. Contact form with client-side validation and feedback.
6. Responsive styling and reduced-motion support.
7. Public repository and static-site deployment workflow.

## Website Screenshots
Add screenshots after running and testing the website. Suggested screenshots:
- `assets/screenshot-desktop.png` — full page or desktop hero.
- `assets/screenshot-projects.png` — project filter and search section.
- `assets/screenshot-mobile.png` — mobile navigation and responsive layout.

Do not claim screenshots have been captured until you add the actual images.

## GitHub Repository Link
`https://github.com/YOUR-USERNAME/portfolio-website`

## Live Website Link
`https://YOUR-USERNAME.github.io/portfolio-website/`

Replace `YOUR-USERNAME` with your GitHub username after publishing.

## Challenges Faced
A key challenge was making a visually consistent layout that remains readable on different screen sizes. Another challenge was combining project filtering and search without one feature overriding the other. Form validation also needed clear feedback so users can identify and correct errors.

## Solutions Implemented
CSS Grid and Flexbox were used for flexible layouts, with media queries for tablet and mobile sizes. JavaScript stores project metadata in an array of objects and applies the selected category and search query together. Validation checks the name, email, subject, and message before showing success feedback. The contact form is a front-end demonstration and does not transmit messages.

## Key Learnings
This project strengthened my understanding of semantic HTML, CSS layout techniques, responsive design, JavaScript functions and events, DOM manipulation, arrays and objects, client-side validation, Git commits, GitHub repositories, and GitHub Pages deployment.

## Future Improvements
Future versions can include real project links, a downloadable résumé, a working contact service, improved accessibility testing, additional projects, and performance optimization.

## Final Reflection
Building this portfolio helped connect the concepts from the internship into one complete project. It also demonstrated the importance of testing, documenting work, using meaningful commits, and publishing a website so that others can access it.
